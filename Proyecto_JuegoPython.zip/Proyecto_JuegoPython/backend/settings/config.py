class Config:
    SECRET_KEY = '8a3610b17a561dc189fed002aaec2d776ea12e59ff054983675f0ec5aa4049af'
    JWT_SECRET_KEY = 'c6b01936363bd184df838d0455df02477696482dc41dc280cad6dedd96920785'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'app_didactica_db'
